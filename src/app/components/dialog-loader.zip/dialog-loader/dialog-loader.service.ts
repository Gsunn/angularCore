import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { BehaviorSubject, map, Observable } from 'rxjs';

import { DialogLoaderComponent, ModalTestData, } from './dialog-loader.component';

@Injectable({
  providedIn: 'root'
})

export class DialogLoaderService {

  private loader = new BehaviorSubject<any>('[]')
  projectDescription$ = this.loader.asObservable()

  constructor(public dialog: MatDialog,
    private http: HttpClient,
    private readonly sanitizer: DomSanitizer) { }

  openInfoModal() { console.log('open info modal') }


  // public getModal(path: string): Observable<any> {
  public getModal(path: string) {

    console.log('getModal ', path)

    const headers = new HttpHeaders({
      'Content-Type':  'text/plain',
    });

    this.http
      .get(path,
        {   headers, responseType: 'text' })
      .subscribe(data => {
        // console.log(data)
        let dato = this.sanitizer.bypassSecurityTrustHtml(data)
        this.loader.next(dato)
        const dialogRef = this.dialog.open(DialogLoaderComponent, {
          width: '100%',
          height: '80%',
          // data
        })

        dialogRef.afterClosed().subscribe(result => {
          console.log('After Close Modal', result);
        });
      });



    //return
    //  this.http.get(path, {
    //   headers,
    //   responseType: 'text'
    // }).pipe(
    //   // This is unsafe if the path and content is not under your control
    //   map(html => {
    //     this.sanitizer.bypassSecurityTrustHtml(html)
    //   })
    // );

  }
}
